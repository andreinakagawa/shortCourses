﻿//Declaração de bibliotecas
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO; //Framework para manipulação de arquivos

namespace Minicurso_Aula2
{
    public partial class Form1 : Form
    {
        //Variáveis globais
        //Este objeto será manipulado quando criarmos um novo jogador
        Jogador jogadorCriado;
        //Lista que irá armazenar cada jogador criado
        List<Jogador> listaJogadores;
        //Objeto para escrita no arquivo
        StreamWriter escritaArquivo;  
        //Objeto para leitura do arquivo
        StreamReader lerArquivo;
        const string nomeArquivo = "jogadores.txt";

        //Inicialização
        public Form1()
        {
            InitializeComponent();
            //Inicialização da lista de jogadores
            listaJogadores = new List<Jogador>();
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            //Toda vez que o botão novo for pressionado,
            //iremos criar um novo objeto da classe Jogador
            //e carregar as informações nos controles da interface
            Jogador novoJogador = new Jogador();
            tbNome.Text = novoJogador.nome;
            tbNacionalidade.Text = novoJogador.nacionalidade;
            nuAltura.Value = (decimal)novoJogador.altura;
            nuPeso.Value = (decimal)novoJogador.peso;
            nuIdade.Value = novoJogador.idade;
            //Atribui o novo jogador ao objeto jogadorCriado
            jogadorCriado = novoJogador;
            //Adicionar o novo jogador à lista de jogadores
            listaJogadores.Add(jogadorCriado);
        }

        private void btAtualizar_Click(object sender, EventArgs e)
        {
            //Atribuir os valores dos controles ao objeto
            jogadorCriado.nome = tbNome.Text;
            jogadorCriado.idade = (int)nuIdade.Value;
            jogadorCriado.altura = (double)nuAltura.Value;
            jogadorCriado.peso = (double)nuPeso.Value;
            jogadorCriado.nacionalidade = tbNacionalidade.Text;
            //Adicionar os jogadores à ComboBox
            cbJogadores.Items.Clear();
            for (int i = 0; i < listaJogadores.Count; i++)
            {
                cbJogadores.Items.Add(listaJogadores[i].nome);
            }
            //foreach (Jogador jog in listaJogadores)
            //{
                //cbJogadores.Items.Add(jog.nome);
            //}
        }

        private void cbJogadores_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Descobrir qual elemento da ComboBox foi selecionado,
            //este elemento corresponde à posição na lista do
            //jogador a ter suas informações carregadas
            //Índice do jogador
            int index = cbJogadores.SelectedIndex;
            Jogador jogadorSelecionado = listaJogadores[index];
            tbNome.Text = jogadorSelecionado.nome;
            tbNacionalidade.Text = jogadorSelecionado.nacionalidade;
            nuAltura.Value = (decimal)jogadorSelecionado.altura;
            nuPeso.Value = (decimal)jogadorSelecionado.peso;
            nuIdade.Value = jogadorSelecionado.idade;

        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            //Cria uma caixa de diálogo que facilita
            //salvar arquivos
            SaveFileDialog caixaSalvar = new SaveFileDialog();
            //Mostra a caixa de diálogo
            //Se a pessoa clicar em OK, continuo para salvar
            //o arquivo
            if (caixaSalvar.ShowDialog() == DialogResult.OK)
            {
                //Recupera o nome do arquivo
                string nomeArquivo = caixaSalvar.FileName;
                //Utilizando o StreamWriter
                //false: indica que o arquivo deve ser sobrescrito
                //true: indica que os dados devem ser adicionados no fim do arquivo
                escritaArquivo = new StreamWriter(nomeArquivo, false);
                //Laço para escrever os dados dos jogadores no arquivo
                //Cada linha corresponde a um atributo do jogador
                foreach (Jogador jog in listaJogadores)
                {
                    escritaArquivo.WriteLine(jog.nome);
                    escritaArquivo.WriteLine(jog.nacionalidade);
                    escritaArquivo.WriteLine(jog.idade);
                    escritaArquivo.WriteLine(jog.altura);
                    escritaArquivo.WriteLine(jog.peso);
                }
                //Salvando o arquivo
                escritaArquivo.Close();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Apresentar uma caixa de diálogo
            //Verificar a resposta do usuário
            if (MessageBox.Show("Deseja carregar uma base de dados?",
                "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //Carregar o arquivo
                OpenFileDialog abrirArquivo = new OpenFileDialog();
                //Verificar se o resultado do diálogo foi OK
                if (abrirArquivo.ShowDialog() == DialogResult.OK)
                {
                    //Ler arquivo
                    lerArquivo = new StreamReader(abrirArquivo.FileName);
                    string linha = "";
                    while ((linha = lerArquivo.ReadLine()) != null)
                    {
                        Jogador jogadorLido = new Jogador();
                        jogadorLido.nome = linha;
                        jogadorLido.nacionalidade = lerArquivo.ReadLine();
                        jogadorLido.idade = Convert.ToInt32(lerArquivo.ReadLine());
                        jogadorLido.altura = Convert.ToDouble(lerArquivo.ReadLine());
                        jogadorLido.peso = Convert.ToDouble(lerArquivo.ReadLine());
                        //Adicionar os jogadores já existentes à listaJogadores
                        listaJogadores.Add(jogadorLido);
                        //Adicionar os nomes dos jogadores existentes à ComboBox
                        cbJogadores.Items.Add(jogadorLido.nome);
                    }
                    lerArquivo.Close(); //Fechar o arquivo
                }
            }
        }
    }
}
