﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Minicurso_Aula2
{
    public class Jogador
    {
        //Modificadores de acesso
        //private: Permite acesso apenas dentro da própria classe
        //public: Permite acesso de qualquer outra classe ou objeto
        public double altura; //cm
        public double peso; //kg
        public int idade; //anos
        public string nacionalidade; //string com a nacionalidade
        public string nome; //string com o nome do jogador

        //Construtor padrão (default)
        //Especifica valores padrões que serão dados aos atributos
        //quando o objeto for criado
        public Jogador()
        {
            altura = 150;
            peso = 60;
            idade = 17;
            nacionalidade = "";
            nome = "Player";
        }
    }
}
