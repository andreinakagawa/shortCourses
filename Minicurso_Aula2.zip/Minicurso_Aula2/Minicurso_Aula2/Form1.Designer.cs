﻿namespace Minicurso_Aula2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btNovo = new System.Windows.Forms.Button();
            this.btAtualizar = new System.Windows.Forms.Button();
            this.nuIdade = new System.Windows.Forms.NumericUpDown();
            this.nuAltura = new System.Windows.Forms.NumericUpDown();
            this.nuPeso = new System.Windows.Forms.NumericUpDown();
            this.tbNacionalidade = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbJogadores = new System.Windows.Forms.ComboBox();
            this.btSalvar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nuIdade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuAltura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuPeso)).BeginInit();
            this.SuspendLayout();
            // 
            // btNovo
            // 
            this.btNovo.Location = new System.Drawing.Point(13, 17);
            this.btNovo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btNovo.Name = "btNovo";
            this.btNovo.Size = new System.Drawing.Size(117, 28);
            this.btNovo.TabIndex = 0;
            this.btNovo.Text = "Novo";
            this.btNovo.UseVisualStyleBackColor = true;
            this.btNovo.Click += new System.EventHandler(this.btNovo_Click);
            // 
            // btAtualizar
            // 
            this.btAtualizar.Location = new System.Drawing.Point(13, 53);
            this.btAtualizar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btAtualizar.Name = "btAtualizar";
            this.btAtualizar.Size = new System.Drawing.Size(117, 28);
            this.btAtualizar.TabIndex = 1;
            this.btAtualizar.Text = "Atualizar";
            this.btAtualizar.UseVisualStyleBackColor = true;
            this.btAtualizar.Click += new System.EventHandler(this.btAtualizar_Click);
            // 
            // nuIdade
            // 
            this.nuIdade.Location = new System.Drawing.Point(312, 39);
            this.nuIdade.Name = "nuIdade";
            this.nuIdade.Size = new System.Drawing.Size(89, 23);
            this.nuIdade.TabIndex = 2;
            // 
            // nuAltura
            // 
            this.nuAltura.Location = new System.Drawing.Point(312, 68);
            this.nuAltura.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.nuAltura.Name = "nuAltura";
            this.nuAltura.Size = new System.Drawing.Size(89, 23);
            this.nuAltura.TabIndex = 3;
            // 
            // nuPeso
            // 
            this.nuPeso.Location = new System.Drawing.Point(312, 97);
            this.nuPeso.Name = "nuPeso";
            this.nuPeso.Size = new System.Drawing.Size(89, 23);
            this.nuPeso.TabIndex = 4;
            // 
            // tbNacionalidade
            // 
            this.tbNacionalidade.Location = new System.Drawing.Point(312, 127);
            this.tbNacionalidade.Name = "tbNacionalidade";
            this.tbNacionalidade.Size = new System.Drawing.Size(89, 23);
            this.tbNacionalidade.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(260, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Idade";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(237, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Altura (m)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(237, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Peso (kg)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(209, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Nacionalidade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(257, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nome";
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(312, 14);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(89, 23);
            this.tbNome.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Jogadores";
            // 
            // cbJogadores
            // 
            this.cbJogadores.FormattingEnabled = true;
            this.cbJogadores.Location = new System.Drawing.Point(13, 110);
            this.cbJogadores.Name = "cbJogadores";
            this.cbJogadores.Size = new System.Drawing.Size(117, 24);
            this.cbJogadores.TabIndex = 13;
            this.cbJogadores.SelectedIndexChanged += new System.EventHandler(this.cbJogadores_SelectedIndexChanged);
            // 
            // btSalvar
            // 
            this.btSalvar.Location = new System.Drawing.Point(13, 141);
            this.btSalvar.Name = "btSalvar";
            this.btSalvar.Size = new System.Drawing.Size(117, 26);
            this.btSalvar.TabIndex = 14;
            this.btSalvar.Text = "Salvar";
            this.btSalvar.UseVisualStyleBackColor = true;
            this.btSalvar.Click += new System.EventHandler(this.btSalvar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 174);
            this.Controls.Add(this.btSalvar);
            this.Controls.Add(this.cbJogadores);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbNome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNacionalidade);
            this.Controls.Add(this.nuPeso);
            this.Controls.Add(this.nuAltura);
            this.Controls.Add(this.nuIdade);
            this.Controls.Add(this.btAtualizar);
            this.Controls.Add(this.btNovo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nuIdade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuAltura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuPeso)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btNovo;
        private System.Windows.Forms.Button btAtualizar;
        private System.Windows.Forms.NumericUpDown nuIdade;
        private System.Windows.Forms.NumericUpDown nuAltura;
        private System.Windows.Forms.NumericUpDown nuPeso;
        private System.Windows.Forms.TextBox tbNacionalidade;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbJogadores;
        private System.Windows.Forms.Button btSalvar;
    }
}

