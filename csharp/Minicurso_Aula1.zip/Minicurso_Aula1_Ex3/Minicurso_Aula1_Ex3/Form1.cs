﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Minicurso_Aula1_Ex3
{
    public partial class Form1 : Form
    {
        const int valorMinimo = 0;
        const int valorMaximo = 100;
        const int intervalo = 1;

        public Form1()
        {
            InitializeComponent();
        }

        //Inicialização
        //Quando a janela for carregada
        private void Form1_Load(object sender, EventArgs e)
        {
            //Ajustar os textos
            label1.Text = "Insira um valor";
            button1.Text = "Alterar!";
            label2.Text = "Controle fino";
            //Ajustar o mínimo e máximo da trackbar
            trackBar1.Minimum = valorMinimo;
            trackBar1.Maximum = valorMaximo;
            //Ajustar o mínimo e máximo do numericUpDown
            numericUpDown1.Minimum = valorMinimo;
            numericUpDown1.Maximum = valorMaximo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int valor = Convert.ToInt32(textBox1.Text);
            if (valor >= valorMinimo && valor <= valorMaximo)
                trackBar1.Value = valor;
            else
                MessageBox.Show("Valor fora dos limites!");
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int valor = Convert.ToInt32(numericUpDown1.Value);
            trackBar1.Value = valor;
        }
    }
}
