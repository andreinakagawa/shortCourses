﻿namespace Minicurso_Aula1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbResposta = new System.Windows.Forms.Label();
            this.btResposta = new System.Windows.Forms.Button();
            this.tbNumero1 = new System.Windows.Forms.TextBox();
            this.tbNumero2 = new System.Windows.Forms.TextBox();
            this.rbSoma = new System.Windows.Forms.RadioButton();
            this.rbSubtração = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Valor 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Valor 2";
            // 
            // lbResposta
            // 
            this.lbResposta.AutoSize = true;
            this.lbResposta.Location = new System.Drawing.Point(20, 198);
            this.lbResposta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbResposta.Name = "lbResposta";
            this.lbResposta.Size = new System.Drawing.Size(51, 20);
            this.lbResposta.TabIndex = 2;
            this.lbResposta.Text = "label3";
            // 
            // btResposta
            // 
            this.btResposta.Location = new System.Drawing.Point(24, 148);
            this.btResposta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btResposta.Name = "btResposta";
            this.btResposta.Size = new System.Drawing.Size(148, 35);
            this.btResposta.TabIndex = 3;
            this.btResposta.Text = "Calcular";
            this.btResposta.UseVisualStyleBackColor = true;
            this.btResposta.Click += new System.EventHandler(this.btResposta_Click);
            // 
            // tbNumero1
            // 
            this.tbNumero1.Location = new System.Drawing.Point(24, 46);
            this.tbNumero1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbNumero1.Name = "tbNumero1";
            this.tbNumero1.Size = new System.Drawing.Size(148, 26);
            this.tbNumero1.TabIndex = 4;
            // 
            // tbNumero2
            // 
            this.tbNumero2.Location = new System.Drawing.Point(24, 112);
            this.tbNumero2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbNumero2.Name = "tbNumero2";
            this.tbNumero2.Size = new System.Drawing.Size(148, 26);
            this.tbNumero2.TabIndex = 5;
            // 
            // rbSoma
            // 
            this.rbSoma.AutoSize = true;
            this.rbSoma.Location = new System.Drawing.Point(267, 46);
            this.rbSoma.Name = "rbSoma";
            this.rbSoma.Size = new System.Drawing.Size(69, 24);
            this.rbSoma.TabIndex = 6;
            this.rbSoma.TabStop = true;
            this.rbSoma.Text = "Soma";
            this.rbSoma.UseVisualStyleBackColor = true;
            // 
            // rbSubtração
            // 
            this.rbSubtração.AutoSize = true;
            this.rbSubtração.Location = new System.Drawing.Point(267, 86);
            this.rbSubtração.Name = "rbSubtração";
            this.rbSubtração.Size = new System.Drawing.Size(101, 24);
            this.rbSubtração.TabIndex = 7;
            this.rbSubtração.TabStop = true;
            this.rbSubtração.Text = "Subtração";
            this.rbSubtração.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 274);
            this.Controls.Add(this.rbSubtração);
            this.Controls.Add(this.rbSoma);
            this.Controls.Add(this.tbNumero2);
            this.Controls.Add(this.tbNumero1);
            this.Controls.Add(this.btResposta);
            this.Controls.Add(this.lbResposta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbResposta;
        private System.Windows.Forms.Button btResposta;
        private System.Windows.Forms.TextBox tbNumero1;
        private System.Windows.Forms.TextBox tbNumero2;
        private System.Windows.Forms.RadioButton rbSoma;
        private System.Windows.Forms.RadioButton rbSubtração;
    }
}