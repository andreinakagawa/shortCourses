﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Minicurso_Aula1
{
    public partial class Form1 : Form
    {
        //VARIÁVEIS GLOBAIS
        const int opSoma = 1;
        const int opSubtracao = 2;

        public Form1()
        {
            InitializeComponent();
        }

        //Declaração de funções
        //Função que retorna um double
        //Recebe como argumento:
        //operacao: Inteiro que indica a operação a ser realizada
        //valor1: double que indica o primeiro valor
        //valor2: double que indica o segundo valor
        double Calculadora(int operacao, double valor1, double valor2)
        {
            double resposta = 0; //variável para o cálculo a ser realizado
            switch (operacao) //Escolhe uma opção de acordo
            {
                case opSoma: //Soma
                    resposta = valor1 + valor2;
                    break;
                
                case opSubtracao: //Subtração
                    resposta = valor1 - valor2;
                    break;

                default: //Nenhum caso
                    resposta = 0;
                    break;
            }

            return resposta; //retorna o valor calculado
        }
      
        private void btResposta_Click(object sender, EventArgs e)
        {
            //VARIÁVEIS LOCAIS

            double valor1 = Convert.ToDouble(tbNumero1.Text);
            double valor2 = Convert.ToDouble(tbNumero2.Text);
            double resp = 0;

            if (rbSoma.Checked) //Soma
            {
                resp = Calculadora(opSoma, valor1, valor2);                
            }
            else if (rbSubtração.Checked) //Subtração
            {
                resp = Calculadora(opSubtracao, valor1, valor2);
            }

            lbResposta.Text = resp.ToString();
        }
    }
}
